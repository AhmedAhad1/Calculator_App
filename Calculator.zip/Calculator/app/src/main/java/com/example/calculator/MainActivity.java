package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import org.mariuszgromada.math.*;
import org.mariuszgromada.math.mxparser.Expression;

public class MainActivity extends AppCompatActivity {
    private TextView tv;
    private TextView tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.textView);
        tv2 = findViewById(R.id.textView2);
    }

    public void displayText(String str){
        String addStr = tv.getText().toString();
        String concat = addStr+str;
        if(concat.charAt(0)=='0'){
            concat= concat.replace("0","");
        }
        tv.setText(concat);

    }
    public void clear_click(View view) {
        tv.setText("0");
        tv2.setText("0");
    }

    public void bracket1_click(View view) {
        displayText("(");

    }
    public void bracket2_click(View view) {
        displayText(")");
    }

    public void percent_click(View view) {
        displayText("%");
    }

    public void divide_click(View view) {
        displayText("÷");
    }

    public void seven_click(View view) {
        displayText("7");

    }

    public void eight_click(View view) {
        displayText("8");
    }

    public void nine_click(View view) {
        displayText("9");
    }

    public void multiply_click(View view) {
        displayText("×");
    }

    public void four_click(View view) {
        displayText("4");
    }

    public void five_click(View view) {
        displayText("5");
    }

    public void six_click(View view) {
        displayText("6");
    }

    public void minus_click(View view) {
        displayText("-");
    }

    public void one_click(View view) {
        displayText("1");
    }

    public void two_click(View view) {
        displayText("2");
    }

    public void three_click(View view) {
        displayText("3");
    }

    public void plus_click(View view) {
        displayText("+");
    }

    public void del_click(View view) {
        int length = tv.getText().length();
        if(length!=0){
            StringBuilder sp = new StringBuilder(tv.getText().toString());
            sp = sp.deleteCharAt(length-1);
            tv.setText(sp.toString());
        }

    }

    public void dot_click(View view) {
        displayText(".");
    }

    public void zero_click(View view) {
        displayText("0");
    }

    public void equal_click(View view) {
        int open =0;
        int close = 0;
        int dot =0;
        String text= tv.getText().toString();
        for (int i=0; i<text.length();i++){
            if(text.charAt(i)=='('){
                open++;
            }
             if(text.charAt(i)==')'){
                close++;
            }

        }

        if(open!=close){
            tv.setText("0");
            Toast.makeText(this,"SYNTAX ERROR!",Toast.LENGTH_LONG).show();
        }
        else{

            String expression = tv.getText().toString();
            expression = expression.replaceAll("÷","/");
            expression = expression.replaceAll("×","*");
            Expression exp = new Expression(expression);
            String result = String.valueOf(exp.calculate());
            tv.setText("0");
            tv2.setText(result);

        }
    }
}